#include <stdio.h>
#include <malloc.h>
#define MAXSIZE 50
typedef int ElemType;
typedef struct
{
    ElemType data[MAXSIZE];
    int top;
} SqStack;

void InitStack(SqStack *&s)
{
    s = (SqStack *)malloc(sizeof(SqStack));
    s->top = -1;
}

void DestroyStack(SqStack *&s)
{
    free(s);
}

bool StackEmpty(SqStack *s)
{
    return s->top == -1;
}
bool Push(SqStack *&s, ElemType e)
{
    if (s->top == MAXSIZE - 1)
        return false;
    s->top++;
    s->data[s->top] = e;
    return true;
}

bool Pop(SqStack *&s, ElemType &e)
{
    if (s->top == -1)
        return false;
    e = s->data[s->top];
    s->top--;
    return true;
}

bool GetTop(SqStack *s, ElemType &e)
{
    if (s->top == -1)
        return false;
    e = s->data[s->top];
    return true;
}

//判断字符串是否为对称串
bool Symmetry(ElemType str[])
{
    int i;
    ElemType e;
    SqStack *st;
    InitStack(st);
    for (i = 0; str[i] != '\0'; i++)
        Push(st, str[i]);
    for (int i = 0; str[i] != '\0'; i++)
    {
        Pop(st, e);
        if (e != str[i])
        {
            DestroyStack(st);
            return false;
        }
        DestroyStack(st);
        return true;
    }
}

/*
共享栈，适用于一方可能用到满，另一方还有很多空间
栈空：top1 == -1   top2 == MAXSIZE
栈满：top1 ==top2-1
进栈出栈的时候top2的操作和top1是反的
*/
