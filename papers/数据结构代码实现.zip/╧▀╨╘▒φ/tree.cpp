#include <stdio.h>
#include <malloc.h>
//1.双亲存储，顺序存储，根节点的父节点设置为-1，其余设置为父节点在顺序中的位置
//求双亲容易，但是求某个节点的子节点难，要遍历整个存储结构
#define MaxSize 100 //假设最多只有100个非零项
#define MaxSons 100 //假设树的度为100
typedef int ElemType;
typedef struct
{
    ElemType data;
    int parent;
} PTree[MaxSize];

//2.子链存储，每个节点有指向所有孩子结点的指针，因为难以确定数目，统一用最大的【树的度】来分配
//找双亲费时，找孩子很方便，树的度与平均度偏差较大时，浪费

#define MaxSons 100 //假设树的度为100
typedef struct node
{
    ElemType data;
    struct node *sons[MaxSons];
} TSonNode;

//以此为基础求树的高度
int TreeHeight1(TSonNode *t)
{
    TSonNode *p;
    int i, h, maxh = 0;
    if (t == NULL)
        return 0;
    else
    {
        for (i = 0; i < MaxSons; i++)
        {
            p = t->sons[i];
            if (p != NULL)
            {
                h = TreeHeight1(p); //求子树的深度
                if (maxh < h)
                    maxh = h;
            }
        }
    }
    return (maxh + 1);
}

//3.孩子兄弟链，每个节点三个域，一个元素，一个指向长子，一个指向兄弟
typedef struct tnode
{
    ElemType data;
    struct tnode *hp; //指向兄弟 horizontal point
    struct tnode *vp; //指向孩子 vertical point
} TSBNode;
//其实这种结构是把树转换为二叉树的存储结构
//最大的优点就是方便的实现树和二叉树的相互转换,缺点时查找父节点麻烦

int TreeHeight2(TSBNode *t)
{
    TSBNode *p;
    int h, maxh = 0;
    if (t == NULL)
        return 0;
    p = t->vp;
    while (p != NULL) //遍历同一层的p
    {
        h = TreeHeight2(p->vp); //求出这一层的最大值
        if (maxh < h)
            maxh = h;
        p = p->hp;
    }
    return maxh + 1;
}