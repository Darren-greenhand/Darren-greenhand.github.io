#include <stdio.h>
#include <stdlib.h>

//假设各结点的关键字是唯一的
typedef int KeyType;
typedef struct
{
    char name[100];
    int years;
} InfoType;

typedef struct node
{
    KeyType key;
    InfoType data;
    struct node *lchild, *rchild;
} BSTNode;

//用根节点bt来唯一标识一棵二叉排序树

//插入关键字k，若已有则返回假
bool InsertBST(BSTNode *&bt, KeyType k)
{
    if (bt == NULL)
    {
        bt = (BSTNode *)malloc(sizeof(BSTNode));
        bt->key = k;
        bt->lchild = bt->rchild = NULL;
        return true;
    }
    else if (k == bt->key)
        return false;
    else if (k < bt->key)
        return InsertBST(bt->lchild, k);
    else if (k > bt->key)
        return InsertBST(bt->rchild, k);
}

//创建一棵二叉排序树是从一个空树开始，一直调用插入就好了。
BSTNode *CreateBST(KeyType A[], int n)
{
    BSTNode *bt = NULL;
    int i = 0;
    while (i < n)
    {
        InsertBST(bt, A[i]);
        i++;
    }
    return bt;
}

//销毁算法和普通的二叉树算法一样
//查找就要方便很多
BSTNode *SearchBST(BSTNode *bt, KeyType k)
{
    if ( bt == NULL || bt->key == k)
        return bt;
    if (k < bt->key)
        return SearchBST(bt->lchild, k);
    else
        return SearchBST(bt->rchild, k);
}

//求最大\最小结点可以利用性质
KeyType maxnode(BSTNode *p)
{
    while (p->rchild != NULL)
        p = p->rchild;
    return (p->key);
}
KeyType minnode(BSTNode *p)
{
    while (p->lchild != NULL)
        p = p->lchild;
    return (p->key);
}

//一定是叶子节点

//删除要分几种情况讨论，是最麻烦的。
//是叶子就直接删除，只有左、右子树就接上去
//同时有左右子树的话可以从左中选最大的结点r代替p，然后把r删除，也可以选右中最小的，一般前者
