/*单链表
记得要设置最后一个是NULL
LinkNode *pre = L,*p = L->next   //这个初始化挺好的！！！
分析多或少1的时候，从开头0各和少数几个的极端情况分析。
头节点L是没有存放数据的，也不算进长度，这就解释了为什么p有时是L有时是L->next，
插入和删除都是先j<i-1找到第i-1然后操作,所以初始化为p = L，因为是对后面那个操作
*/
#include <stdio.h>
#include <malloc.h>
#define MaxSize 50
typedef int ElemType;
typedef struct LNode
{
    ElemType data;
    struct LNode *next;
} LinkNode; //顺序表类型

//头插法
void CreateListF(LinkNode *&L, ElemType a[], int n)
{
    LinkNode *s; //工具节点上线
    L = (LinkNode *)malloc(sizeof(LinkNode));
    L->next = NULL; //经典创建
    for (int i = 0; i < n; i++)
    {
        s = (LinkNode *)malloc(sizeof(LinkNode));
        s->data = a[i];
        s->next = L->next;
        L->next = s;
        //头插四件套
    }
}

//尾插法
void CreateListR(LinkNode *&L, ElemType a[], int n)
{
    LinkNode *s, *r;
    L = (LinkNode *)malloc(sizeof(LinkNode));
    r = L;
    for (int i = 0; i < n; i++)
    {
        s = (LinkNode *)malloc(sizeof(LinkNode));
        s->data = a[i];
        r->next = s;
        r = s;
    }
    r->next = NULL;
}

void InitList(LinkNode *&L)
{
    L = (LinkNode *)malloc(sizeof(LinkNode));
    L->next = NULL;
}

void DestroyList(LinkNode *&L)
{
    LinkNode *pre = L, *p = L->next; //这个初始化挺好的！！！
    while (p != NULL)
    {
        free(pre);
        pre = p;
        p = p->next;
    }
    free(pre); //最后一步别忘了！！
}

bool ListEmpty(LinkNode *L)
{
    return (L->next == NULL);
}

int ListLength(LinkNode *L)
{
    int n = 0;
    LinkNode *p = L;
    while (p->next != NULL)
    {
        n++;
        p = p->next;
    }
    return n;
}

void DispList(LinkNode *L)
{
    LinkNode *p = L->next;
    while (p != NULL)
    {
        printf("%d", p->data);
        p->next;
    }
    printf("\n");
}

bool GetElem(LinkNode *L, int i, ElemType &e)
{
    int j = 0;
    if (i <= 0)
        return false; //别漏了
    LinkNode *p = L;
    while (j < i && p)
    {
        j++;
        p = p->next;
    }
    if (p == NULL)
        return false;
    else
    {
        e = p->data;
        return true;
    }
}

//
int LocateElem(LinkNode *L, ElemType e)
{
    int i = 1;
    LinkNode *p = L->next;
    while (p != NULL && p->data != e)
    {
        p = p->next;
        i++;
    }
    if (p == NULL)
        return 0;
    else
        return i;
}

bool ListInsert(LinkNode *&L, int i, ElemType e)
{
    int j = 0;
    LinkNode *p = L, *s;
    if (i <= 0)
        return false;
    while (j < i - 1 && p != NULL)
    {
        j++;
        p = p->next;
    }
    if (p == NULL)
        return false;
    else
    {
        s = (LinkNode *)malloc(sizeof(LinkNode));
        s->data = e;
        s->next = p->next;
        p->next = s;
        return true;
    }
}

bool ListDelete(LinkNode *&L, int i, ElemType &e)
{
    int j = 0;
    LinkNode *p = L, *q;
    if (i <= 0)
        return false;
    while (j < i - 1 && p != NULL)
    {
        j++;
        p = p->next;
    }
    if (p == NULL)
        return false;
    else
    {
        q = p->next;
        if (q == NULL)
            return false; //多检验一次，因为检验不到这里
        e = q->data;
        p->next = q->next;
        free(q);
        return true;
    }
}

//****************************************************************************************************
//删除一个单链表L中元素最大的节点（假设唯一）插入一个标记就好了
void delmaxnode(LinkNode *&L)
{
    LinkNode *p = L->next, *pre = L, *maxp = p, *maxpre = pre;
    while (p != NULL)
    {
        if (maxp->data < p->data)
        {
            maxp = p;
            maxpre = pre;
        }
        pre = p;
        p = p->next;
    }
    maxpre->next = maxp->next;
    free(maxp);
}

//使元素递增有序排列，没有那么巧妙
void sort(LinkNode *&L)
{
    LinkNode *p, *pre, *q;
    p = L->next->next;
    L->next->next = NULL;
    //p接下了第二个节点，原来的头和首被当作了新的有序链表
    while (p != NULL)
    {
        q = p->next; //储存下一个
        pre = L;     //每次pre都从头扫描一遍。。。
        while (pre->next != NULL && pre->next->data < p->data)
            pre = pre->next;
        p->next = pre->next;
        pre->next = p;
        p = q;
    }
}

void UnionList1(LinkNode *LA, LinkNode *LB, LinkNode *&LC)
{
    LinkNode *pa = LA->next, *pb = LB->next, *r, *s; //尾插法和创建
    LC = (LinkNode *)malloc(sizeof(LinkNode));
    while (pa != NULL && pb != NULL)
    {
        if (pa->data >= pb->data)
        {
            s = (LinkNode *)malloc(sizeof(LinkNode));
            s->data = pa->data;
            r->next = s;
            r = s;
            pa = pa->next;
        }
        else
        {
            if (pb->data > pa->data)
            {
                s = (LinkNode *)malloc(sizeof(LinkNode));
                s->data = pb->data;
                r->next = s;
                r = s;
                pb = pb->next;
            }
        }
        while (pa != NULL)
        {
            s = (LinkNode *)malloc(sizeof(LinkNode));
            s->data = pa->data;
            r->next = s;
            r = s;
            pa = pa->next;
        }
        while (pb != NULL)
        {
            s = (LinkNode *)malloc(sizeof(LinkNode));
            s->data = pb->data;
            r->next = s;
            r = s;
            pb = pb->next;
        }
        r->next = NULL;
    }
