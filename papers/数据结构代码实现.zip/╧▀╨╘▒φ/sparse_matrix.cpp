#include <stdio.h>
#include <malloc.h>
#define M 100       //行数
#define N 200       //列数
#define MaxSize 100 //假设最多只有100个非零项
typedef int ElemType;
typedef struct
{
    int r;      //行号
    int c;      //列号
    ElemType d; //元素值
} TupNode;
typedef struct
{
    int rows;
    int cols;
    int nums;
    TupNode data[MaxSize];
} TSMatrix;

//从二维稀疏矩阵创建三元组表示,有点新奇哈哈
void CreateMat(TSMatrix &t, ElemType A[M][N])
{
    int i, j;
    t.rows = M;
    t.cols = N;
    t.nums = 0;
    for (i = 0; i < M; i++)
        for (j = 0; j < N; j++)
            if (A[i][j] != 0)
            {
                t.data[t.nums].d = A[i][j];
                t.data[t.nums].r = i;
                t.data[t.nums].c = j;
                t.nums++;
            }
}

//三元组元素的赋值，分成0和非0两种情况,要理解好他这个数据结构是怎样的
bool Value(TSMatrix &t, ElemType x, int i, int j)
{
    int k = 0, k1;
    if (i < 0 || j < 0 || i >= t.rows || j >= t.cols)
        return false;
    while (k < t.nums && t.data[k].r < i)
        k++;
    while (k < t.nums && t.data[k].r == i && t.data[k].c < j)
        k++; //这个查找方式。。。秀啊
    if (t.data[k].r == i && t.data[k].c == j)
        t.data[k].d = x; //存在这样的非0元素
    else
    {
        for (k1 = t.nums - 1; k1 >= k; k1--) //这里注意带 =，不然第k项原本有意义的就被吃了
        {
            t.data[k1 + 1].r = t.data[k1].r;
            t.data[k1 + 1].c = t.data[k1].c;
            t.data[k1 + 1].d = t.data[k1].d;
        }
        t.data[k].r = i;
        t.data[k].c = j;
        t.data[k].d = x;
        t.nums++;
    }
    return true;
}

bool Assign(TSMatrix t, ElemType &x, int i, int j)
{
    int k = 0;
    if (i < 0 || j < 0 || i >= t.rows || j >= t.cols)
        return false;
    while (k < t.nums && t.data[k].r < i)
        k++;
    while (k < t.nums && t.data[k].r == i && t.data[k].c < j)
        k++;
    if (t.data[k].r == i && t.data[k].c == j)
    {
        x = t.data[k].d;
        return true;
    }
    else
        x = 0; //返回0
    return false;
}

void DispMat(TSMatrix t)
{
    int k;
    if (t.nums <= 0)
        return;
    printf("\t%d\t%d\t%d\n", t.rows, t.cols, t.data);
    printf("\t------------------------\t");
    for (k = 0; k < t.nums; k++)
        printf("\t%d\t%d\t%d\n", t.data[k].r, t.data[k].c, t.data[k].d);
}

//转置，把列号放在前面，那就要依次查找列号，高效的是快速转置
void TranTat(TSMatrix t, TSMatrix &tb)
{
    int k, k1 = 0, v; //k1记录tb中的元素个数
    tb.rows = t.cols;
    tb.cols = t.rows;
    tb.nums = t.nums;
    if (t.nums != 0)
    {
        for (v = 0; v < t.cols; v++) //每一列都完整的遍历一遍卧槽
            for (k = 0; k < t.nums; k++)
                if (t.data[k].c == v)
                {
                    tb.data[k1].r = t.data[k].c;
                    tb.data[k1].c = t.data[k].r;
                    tb.data[k1].d = t.data[k].d;
                    k1++;
                }
    }
}

//接下来是十字链表的数据结构P178
#define Max ((M) > (N) ? M : N)
typedef struct mtxn
{
    int row;
    int col;
    struct mtxn *right, *down;  //向右循环的行指针和向下循环的列指针
    union
    {
        ElemType value;
        struct mtxn *link; //指向下个头节点
    } tag;

} MatNode;

//代价是运算算法比较复杂