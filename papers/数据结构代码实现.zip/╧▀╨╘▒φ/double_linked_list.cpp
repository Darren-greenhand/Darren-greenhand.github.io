/*双链表
return true;//不要漏了
*/
#include <stdio.h>
#include <malloc.h>
typedef int ElemType;
typedef struct DNode
{
    ElemType data;
    struct DNode *prior;
    struct DNode *next;
} DLinkNode; //顺序表类型

//建立头插法
void CreateListF(DLinkNode *&L, ElemType a[], int n)
{
    DLinkNode *s;
    L = (DLinkNode *)malloc(sizeof(DLinkNode));
    L->prior = L->next = NULL;
    for (int i = 0; i < n; i++)
    {
        s = (DLinkNode *)malloc(sizeof(DLinkNode));
        s->prior = L;
        s->data = a[i];
        s->next = L->next;

        //一共要练4条，但是这一条可能不需要链接👇
        if (L->next != NULL)
            L->next->prior = s;
        L->next = s;
    }
}

void CreateListR(DLinkNode *&L, ElemType a[], int n)
{
    DLinkNode *s, *r;
    L = (DLinkNode *)malloc(sizeof(DLinkNode));
    r = L;
    for (int i = 0; i < n; i++)
    {
        s = (DLinkNode *)malloc(sizeof(DLinkNode));
        s->data = a[i];
        r->next = s;
        s->prior = r;
        r = s;
    }
    r->next = NULL;
}

//其余操作很多类似单链表，插入和删除有点区别罢了,工具节点叫s
bool ListInsert(DLinkNode *&L, int i, ElemType e)
{
    int j = 0;
    DLinkNode *p = L, *s;
    if (i <= 0)
        return false;
    while (j < i - 1 && p != NULL)
    {
        j++;
        p = p->next;
    }
    if (p == NULL)
        return false;
    else
    {
        s = (DLinkNode *)malloc(sizeof(DLinkNode));
        s->data = e;
        s->prior = p;
        s->next = p->next;
        if (p->next != NULL)
            p->next->prior = s;
        p->next = s;
        return true; //不要漏了
    }
}
//****************************************************************************************************
//工具节点叫q
bool ListDelete(DLinkNode *&L, int i, ElemType &e)
{
    int j = 0;
    DLinkNode *p = L, *q;
    if (i <= 0)
        return false;
    while (j < i && p != NULL)
    {
        j++;
        p = p->next;
    }
    if (p == NULL)
        return false;
    else
    {
        q = p->next;
        e = q->data;
        p->next = q->next;
        if (q->next != NULL)
            q->next->prior = p;
        free(q);
        return true;
    }
}

//逆置,头插法就能进行逆置,头节点还能保留
void reverse(DLinkNode *&L)
{
    DLinkNode *p = L->next, *q;
    L->next = NULL;
    while (p != NULL)
    {
        q = p->next;
        p->next = L->next;
        if (L->next != NULL)
            L->next->prior = p;
        p->prior = L;
        L->next = p->next;
        p = q; //继续指向后继节点
    }
}

//双链表的删除是不需要工具节点的，这里用一个循环双链表的例子展示一下,删除第一个data为x的节点
bool delelem(DLinkNode *&L, ElemType x)
{
    DLinkNode *p = L->next; //不需要工具点，p可以直接指向操作节点，而不是前一个
    while (p != L && p->data != x)
        p = p->next;
    if (p == L)
        return false;
    else
    {
        p->next->prior = p->prior;
        p->prior->next = p->next;
        free(p);
        return true;
    }
}

//循环双链表判断对称
bool Symm(DLinkNode *L)
{
    bool same = true; //这类题的典型flag
    DLinkNode *p = L->next;
    DLinkNode *q = L->prior;
    while (same)
    {
        if (p->data != q->data)
            same = false;
        else
        {
            if (p == q || p == q->prior)
                break; //当相等（奇数）或相邻（偶数），为结束条件
            q = q->prior;
            p = p->next;
        }
    }
    return same;
}

