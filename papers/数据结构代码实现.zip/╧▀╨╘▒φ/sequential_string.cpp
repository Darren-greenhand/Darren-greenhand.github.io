#include <stdio.h>
#include <malloc.h>
#define MAXSIZE 50
typedef struct
{
    char data[MAXSIZE];
    int length;
} SqString;

//这里用的不是指针，是直接传了顺序串进来，我不知道这个顺序串到底有什么意义
void StrAssign(SqString &s, char cstr[])
{
    int i;
    for (int i = 0; cstr[i] != '\0'; i++)
        s.data[i] = cstr[i];
    s.length = i;
}

void DestoryStr(SqString &s) {} //因为这个不是malloc分配的，会自动回收
void StrCopy(SqString &s, SqString t)
{
    int i;
    for (i = 0; i < t.length; i++)
    {
        s.data[i] = t.data[i];
        s.length = t.length;
    }
}

//判断相等
bool StrEqual(SqString s, SqString t)
{
    bool same = true;
    int i;
    if (s.length != t.length) //能用长度排除就直接去世吧
        same = false;
    else
        for (i = 0; i < s.length; i++)
            if (s.data[i] != t.data[i])
            {
                same = false;
                break;
            }
    return same;
}

int StrLength(SqString s)
{
    return s.length;
}

//链接
SqString Concat(SqString s, SqString t)
{
    SqString str;
    int i;
    str.length = s.length + t.length;
    for (i = 0; i < s.length; i++)

        str.data[i] = s.data[i];
    for (i = 0; i < t.length; i++)
        str.data[s.length + i] = t.data[i];
    return str;
}

//求子串，返回从第i个字符开始的，连续j个字符组成的字串
SqString SubStr(SqString s, int i, int j)
{
    int k;
    SqString str;
    str.length = 0;
    if (i <= 0 || i > s.length || j < 0 || i + j - 1 > s.length) //i+j-1有点绕，但是因为i的那个字符他是要算进去的
        return str;
    for (k = i - 1; k < i + j - 1; k++) //i-1开始，因为逻辑和物理差1
    {
        str.data[k - i + 1] = s.data[k];
    }
    str.length = j;
    return str;
}

//这个里面的加减1有点骚，理解好了这类题就不怕了。
SqString IntStr(SqString s1, int i, SqString s2)
{
    int j;
    SqString str;
    str.length = 0;
    if (i <= 0 || i > s1.length + 1) //插入的时候是可以多插一位的
        return str;                  //返回空串
    for (j = 0; j < i - 1; j++)
        str.data[j] = s1.data[j];
    for (j = 0; j < s2.length; j++)
        str.data[i + j - 1] = s2.data[j];
    for (j = i - 1; j < s2.length; j++)
        str.data[s2.length + j] = s1.data[j];
    str.length = s1.length + s2.length;
    return str;
}

SqString DelStr(SqString s, int i, int j)
{
    int k;
    SqString str;
    str.length = 0; //便于返回空串
    if (i <= 0 || i > s.length || i + j - 1 > s.length || j < 0)
        return str;
    for (k = 0; k < i; k++)
        str.data[k] = s.data[k];
    for (k = i + j - 1; k < s.length; k++)
        str.data[k - j] = s.data[k];
    str.length = s.length - j;
}

//将i开始到j的字串用t替换
//我好像有点明白了，他在for循环里用的索引对标某个长度，很简单，其他的操作通过改变数组索引的表达式来实现。
SqString RepStr(SqString s, int i, int j, SqString t)
{
    int k = 0;
    SqString str;
    str.length = 0;
    if (i <= 0 || i > s.length || i + j - 1 > s.length - 1 || j < 0)
        return str;
    for (k = 0; k < i; k++)
        str.data[k] = s.data[k];
    for (k = 0; k < t.length; k++)
        str.data[k + j] = t.data[k];
    for (k = i + j - 1; k < s.length; k++)
        str.data[t.length - j + k] = s.data[k];
    str.length = s.length - j + t.length;
    return str;
}

void DispStr(SqString s)
{
    int i;
    if (s.length > 0)
    {
        for (i = 0; i < s.length; i++)
            printf("%c", s.data[i]);
    }
    printf("\n");
}

//比较大小
int Strcmp(SqString s, SqString t)
{
    int i, comlen;
    if (s.length < t.length)
        comlen = s.length;
    else
        comlen = t.length; //这里也包括了相等的情况
    for (i = 0; i < comlen; i++)
        if (s.data[i] > t.data[i])
            return 1;
        else if (s.data[i] < t.data[i])
            return -1;
    if (s.length == t.length)
        return 0;
    else if (s.length > t.length)
        return 1;
    else
        return -1;
}

//求s中出现的第一个最长连续相同字符构成的平台，用index开始索引，maxlen保存长度
void LongestString(SqString s, int &index, int &maxlen)
{
    index = maxlen = 0;
    int length, i = 1, start; //用来保存局部的  这种全局和局部都有对应的变量！
    while (i < s.length)
    {
        start = i - 1; //留个物理索引
        length = 1;
        while (i < s.length && s.data[i] == s.data[i - 1])
        {
            i++;
            length++;
        }
        if (maxlen < length)
        {
            maxlen = length;
            index = start;
        }
    }

}

//Brute-Force
int BF(SqString s, SqString t)
{
    int i =0,j=0;
    while(i<s.length && j<t.length)
    {
        if(s.data[i] == t.data[j])
        i++,j++;
        else
        i = i-j+1,j=0;//i回退到最初的后一位，j清空
    }
    if(j>=t.length) return(i-t.length);
    else return -1;
}
