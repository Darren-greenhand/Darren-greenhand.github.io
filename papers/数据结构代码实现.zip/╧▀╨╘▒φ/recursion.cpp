#include <stdio.h>
#include <malloc.h>
#define MAXSIZE 50
typedef struct
{
    int n;
    char x, y, z;
    bool flag;
} ElemType;
typedef struct
{
    ElemType data[MAXSIZE];
    int top;
} StackType;

void InitStack(StackType *&s)
{
    s = (StackType *)malloc(sizeof(StackType));
    s->top = -1;
}

void DestroyStack(StackType *&s)
{
    free(s);
}

bool StackEmpty(StackType *s)
{
    return s->top == -1;
}
bool Push(StackType *&s, ElemType e)
{
    if (s->top == MAXSIZE - 1)
        return false;
    s->top++;
    s->data[s->top] = e;
    return true;
}

bool Pop(StackType *&s, ElemType &e)
{
    if (s->top == -1)
        return false;
    e = s->data[s->top];
    s->top--;
    return true;
}

bool GetTop(StackType *s, ElemType &e)
{
    if (s->top == -1)
        return false;
    e = s->data[s->top];
    return true;
}

/*
共享栈，适用于一方可能用到满，另一方还有很多空间
栈空：top1 == -1   top2 == MAXSIZE
栈满：top1 ==top2-1
进栈出栈的时候top2的操作和top1是反的
*/

//********************************************************************
//一般，尾递归算法可以通过循环或者迭代转换为等价的非递归算法
int Fib2(int n)
{
    int a = 1, b = 1, i, s;
    if (n == 1 || n == 2)
        return 1;
    else
    {
        for (i = 3; i <= n; i++)
        {
            s = a + b;
            a = b;
            b = s;
        }
        return s;
    }
}

/*对于不是尾递归的复杂递归，可以在 理解递归调用实现过程 的基础上
用栈来模拟递归执行过程(这是关键啊)，从而将其转换为等价的非递归算法*/
//汉诺塔问题的非递归实现：注意栈的结构决定了e1,e3的push顺序和实际执行顺序相反！

void Hanoi2(int n, char x, char y, char z)
{
    StackType *st;
    ElemType e, e1, e2, e3; //一共要用到这么多变量
    if (n <= 0)
        return;
    InitStack(st);
    e.n = n;
    e.x = x;
    e.y = y;
    e.z = z;
    Push(st, e);

    while (!StackEmpty(st))
    {
        Pop(st, e);
        if (e.flag == false)
        {
            e1.n = e.n - 1;
            e1.x = e.y;
            e1.y = e.x;
            e1.z = e.z;
            if (e1.n == 1)
                e1.flag = true;
            else
                e1.flag = false;
            Push(st, e1);

            e2.n = e.n;
            e2.x = e.x;
            e2.y = e.y;
            Push(st, e2);

            e3.n = e.n - 1;
            e3.x = e.x;
            e3.y = e.z;
            e3.z = e.y;
            if (e3.n == 1)
                e3.flag = true;
            else
                e3.flag = false;
            Push(st, e3);
        }
        else
            printf("将%d个盘片从%c移动到%c\n", e.n, e.x, e.z);
    }
    DestroyStack(st);
}

//递归算法执行中，最长的递归调用的链长称为该算法的递归调用深度
/*设计队规算法的基本步骤是先确定问题的递归模型，再转化成C/C++语言的函数
确定递归模型的步骤是：
1. 对原问题f(n)进行分析，假设出合理的小问题f(n-1)
2. 给出f(n)与f(n-1)甚至更多项之间的关系，也就是确定递归体，也
就是数学归纳法中的假设i = n-1成立，求证 i =n
3. 找到特定情况如f(1)作为递归出口 */


//有0~i个元素，求最小值，思路是找到前面的最小值
double Min(double A[], int i)
{
    double min;
    if (i == 0)
        return A[0];
    else
    {
        min = Min(A, i - 1);
        if (min > A[i])
            return A[i];
        else
            return min;
    }
}

