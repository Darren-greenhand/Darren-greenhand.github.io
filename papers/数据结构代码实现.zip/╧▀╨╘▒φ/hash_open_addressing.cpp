#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>

//用开放地址法构造的哈希表的运算算法
#define NULLKEY -1 //空关键字值
#define DELKEY -2  //被删除关键字值
typedef int KetType;
typedef struct
{
    KetType key;
    int count; //探测次数域
} HashTable;

void InsertHT(HashTable ha[], int &n, int m, int p, KetType k)
{
    int i, adr;
    adr = k % p;                                         //adr是关键字k对应的哈希值
    if (ha[adr].key == NULLKEY || ha[adr].key == DELKEY) //可以直接放入
    {
        ha[adr].key = k;
        ha[adr].count = 1;
    }
    else
    {
        i = 1; //i 记录k发生的次数
        do
        {
            adr = (adr + 1) % m;
            i++;
        } while (ha[adr].key != NULLKEY && ha[adr].key != DELKEY);
        ha[adr].key = k;
        ha[adr].count = i; //设置探测次数
    }
    n++; //哈希表中总元素个数增1
}

void CreateHT(HashTable ha[], int &n, int m, int p, KetType keys[], int nl)
{
    //由关键字序列keys[0..nl-1]创建哈希表
    for (int i = 0; i < m; i++)
    {
        ha[i].key = NULLKEY;
        ha[i].count = 0;
    }
    n = 0;
    for (int i = 0; i < nl; i++)
        InsertHT(ha, n, m, p, keys[i]); //插入nl个
}

//删除算法
//在开放地址法处理的哈希表上不能简单的删除，因为在查找算法中空是查找失败，应该置特殊值
bool DeleteHT(HashTable ha[], int &n, int m, int p, KetType k)
{
    int adr;
    adr = k & p;
    while (ha[adr].key != NULLKEY && ha[adr].key != DELKEY)
        adr = (adr + 1) % m;
    if (ha[adr].key == k)
    {
        ha[adr].key = DELKEY;
        return true;
    }
    else
        return false;
}

void SearchHT(HashTable ha[], int m, int p, KetType k)
{
    int i = 1, adr;
    adr = k % p;
    while (ha[adr].key != NULLKEY && ha[adr].key != k)
    {
        i++;
        adr = (adr + 1) % m; //线性探测
    }
    if (ha[adr].key == k)
        printf("Success:%d compare %d times", k, i);
    else
        printf("fail");
}