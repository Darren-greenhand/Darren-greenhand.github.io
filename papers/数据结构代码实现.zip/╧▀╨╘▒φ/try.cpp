#include <stdio.h>
void wocao(int *a)
{

    printf("%p", a);
    a++;
}
int main()
{
    int a = 100;
    int *b = &a;
    wocao(&a);
    printf("%p", &a);
}