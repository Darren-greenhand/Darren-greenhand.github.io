#include <stdio.h>
#include <stdlib.h>

//拉链法
typedef int KeyType;
typedef struct node
{
    KeyType key;
    struct node *next;
} NodeType;
typedef struct
{
    NodeType *firstp;
} HashTable;

//理解这个HashTable ha数组，下标即为“地址”
void InsertHT(HashTable ha[], int &n, int p, KeyType k)
{
    int adr;
    adr = k % p;
    NodeType *q;
    q = (NodeType *)malloc(sizeof(NodeType));
    q->key = k;
    q->next = NULL;
    if (ha[adr].firstp == NULL)
        ha[adr].firstp = q;
    else
    {
        q->next = ha[adr].firstp;
        ha[adr].firstp = q;
    }
    n++;
}

void CreateHT(HashTable ha[], int &n, int m, int p, KeyType keys[], int nl)
//由关键字序列keys[0..nl-1]创建哈希表
{
    for (int i = 0; i < m; i++)
        ha[i].firstp = NULL;
    n = 0;
    for (int i = 0; i < nl; i++)
        InsertHT(ha, n, p, keys[i]);
}

//删除算法 在逻辑上更为简单，可以直接删除
bool DeleteHT(HashTable ha[], int &n, int m, int p, KeyType k) //删除哈希表中的关键字k
{
    int adr;
    adr = k % p;
    NodeType *q, *preq;
    q = ha[adr].firstp;
    if (q = NULL)
        return false;
    if (q->key == k)
    {
        ha[adr].firstp = q->next;
        free(q);
        n--;
        return true;
    }
    //首节点不为k时
    preq = q;
    q = q->next;
    while (q != NULL)
    {
        if (q->key == k)
            break;
        q = q->next;
    }
    if (q != NULL)
    {
        preq->next = q->next;
        free(q);
        n--;
        return true;
    }
    else
        return false;
}

void SearchHT(HashTable ha[], int p, KeyType k)
{
    int i = 0, adr;
    adr = k % p;
    NodeType *q = ha[adr].firstp;
    while (q != NULL)

    {
        i++;
        if (q->key == k)
            break;
        q = q->next;
    }
    if (q != NULL)
        printf("success");
    else
        printf("fail");
}