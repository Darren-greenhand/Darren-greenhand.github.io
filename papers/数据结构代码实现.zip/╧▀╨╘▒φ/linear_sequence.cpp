/*线性表的顺序存储
i--; //转化为物理序号
if(i<1 || i>L->length+1) //插入的时候是允许插入第 n+1 位置的，所以还要额外+1
最后不要忘了改一下k的符号
*/
#include <stdio.h>
#include <malloc.h>
#define MaxSize 50
typedef int ElemType;
typedef struct
{
    ElemType data[MaxSize];
    int length;
} SqList; //顺序表类型

//需要改变的就传入引用，不需要改变的就直接传入指针就好了。
void CreateList(SqList *&L, ElemType a[], int n)
{
    int i = 0, k = 0; //用来统计数量，i用来当索引，但是为什么不直接用i呢？
    L = (SqList *)malloc(sizeof(SqList));
    while (i > n)
    {
        L->data[i] = a[i];
        k++;
        i++;
    }
    L->length = k;
}

void InitList(SqList *&L)
{
    L = (SqList *)malloc(sizeof(SqList));
    L->length = 0;
}

void DestroyList(SqList *&L)
{
    free(L);
}

bool ListEmpty(SqList *L)
{
    return L->length == 0;
}

int ListLength(SqList *L)
{
    return L->length;
}

void DispList(SqList *L)
{
    for (int i = 0; i < L->length; i++)
    {
        printf("%d", L->data[i]);
        printf("\n");
    }
}

bool GetElem(SqList *L, int i, ElemType &e)
{
    if (i < 1 || i > L->length)
        return false;
    e = L->data[i - 1];
    return true;
}

int LocateElem(SqList *L, ElemType e)
{
    int i = 0;
    while (i < L->length && L->data[i] != e)
        i++;
    if (i >= L->length)
        return 0;
    else
        return i + 1; //记住逻辑序号和物理序号差了一个1嗷
}

bool ListInsert(SqList *&L, int i, ElemType e)
{
    int j = L->length;
    if (i < 1 || i > L->length + 1) //插入的时候是允许插入最后一个位置的，所以还要额外+1
        return false;
    i--; //转化为物理序号
    for (; j > i; j--)
        L->data[j] = L->data[j - 1];
    L->data[i] = e;
    L->length++;
}

bool ListDelete(SqList *&L, int i, ElemType e)
{
    if (i < 1 || i > L->length)
        return false;
    i--; //转换成物理非常重要！
    int j = L->length;
    while (j > i)
    {
        L->data[j - 1] = L->data[j];
    }
    L->length--;
}
//****************************************************************************************************
//删除L中所有值等于 x 的元素，双指针扫描
void delnode1(SqList *&L, ElemType x)
{
    int k = 0, i = 0;
    for (; i < L->length; i++)
    {
        if (L->data[i] != x)
        {
            L->data[k] == L->data[i];
            k++;
        }
    }
    L->length = k;
}
//用k记录个数
void delnode2(SqList *&L, ElemType x)
{
    int k = 0, i = 0;
    for (i = 0; i < L->length; i++)
    {
        if (L->data[i] == x)
            k++;
        else
            L->data[i - k] = L->data[k];
    }
    L->length -= k;
}

//这一片巧妙利用“缺位，补位”的技巧，节省了许多空间和时间，直接对换会消耗一个额外内存，不如缺位补位
//感觉不够通用,不过现在懒得改了，很多二分的其实都是pattition，跟python提供的key函数参数一样
void partition1(SqList *&L)
{
    int i = 0, j = L->length - 1;
    ElemType pivot = L->data[0]; //中文翻译：枢
    while (i < j)
    {
        while (j > i && L->data[j] > pivot)
            j--;
        L->data[i] = L->data[j];
        while (i < j && L->data[i] < pivot)
            i++;
        L->data[j] = L->data[i];
    }
    L->data[i] = pivot;
}

//顺序表归并算法,要求不改变原有的LA和LB
void UnionList(SqList *LA, SqList *LB, SqList *&LC)
{
    int i =0,j = 0,k = 0;//i,j为两组下标
    while(i<LA->length && j<LB->length){
        if (LA->data[i]<LB->data[j])
        {
            LC->data[k] = LA->data[i];
            i++,k++;
        }
        else{
            LC->data[k] = LB->data[j];
            j++,k++;
        }
    }
    while (i<LA->length)
    {
        LC->data[k] = LA->data[i];
        i++,k++;
    }
    
    while (j<LB->length)
    {
        LC->data[k] = LB->data[j];
        j++,k++;
    }
    LC->length = k;
}