#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>

//线性表分顺序和链式，只介绍顺序表，属于静态查找。
typedef int KeyType;
typedef struct
{
    char name[100];
    int years;
} InfoType;

typedef struct
{
    KeyType key;   //关键字
    InfoType data; //其他数据
} RecType;

//顺序查找，ASL成功 = (n+1)/2 ASL失败 = n
int SeqSearch(RecType R[], int n, KeyType k)
{
    int i = 0;
    while (R[i].key != k && i < n)
        i++;
    if (i >= n)
        return 0;
    else
        return i + 1; //逻辑值要加一
}
//从精简算法，提高查找速度的角度说，可以在R末尾增加一个关键字为k的记录为哨兵，就不用判断i是否超界
int SeqSearch1(RecType R[], int n, KeyType k)
{
    int i = 0;
    R[n].key = k;
    while (R[i].key != k)
        i++;
    if (i == n)
        return 0;
    else
        return i + 1;
}

//折半查找
//要求有序表,mid = (low+high)/2向下取整，成功返回逻辑序号，失败返回0
int BinSearch(RecType R[], int n, KeyType k)
{
    int low = 0, high = n - 1, mid;
    while (low <= high)
    {
        mid = (low + high) / 2;
        if (k == R[mid].key)
            return mid + 1;
        if (k < R[mid].key)
            high = mid - 1;
        else
            low = mid + 1;
    }
    return 0;
}
//好精简的算法！
//可以用判定树刻画，n种成功情况，成功时比较次数恰为层数和n+！种失败情况。失败时比较次数为层数-1
//ASLbn = log2(n+1)-1  最坏性能和平均性能相当接近,归纳起来复杂度为O（log2n）

//索引结构和分块查找
/*索引项一般为（关键字，地址），可以现在有序索引表中快速查找，然后通过地址找到
提高了查找效率，但是需要建立索引表会增加时空开销*/
#define MAXI 10000 //索引表最大容量。
typedef struct
{
    KeyType key;
    int link; //对应在存储表里的下标
} IdxType;

int IdxSearch(IdxType I[], int b, RecType R[], int n, KeyType k)
{
    int s = (n + b - 1) / b; //s为每块的元素个数，I的长度为b
    int low = 0, high = b - 1, mid, i;
    while (low <= high)
    {
        mid = (low + high) / 2;
        if (I[mid].key >= k)
            high = mid - 1;
        else
            low = mid + 1;
    }

    //接下来在该块中查找
    i = I[high + 1].link; //记住是high+1，总会取到偏小的一个
    while (i < I[high + 1].link + s - 1 && R[i].key != k)
        i++;
    if (i <= I[high + 1].link + s - 1)
        return i + 1;
    else
        return 0;
}
/*折半查找配合时，成功查找的平均长度为ASLblk = ASLbn + ASLsq
= log2(b+1) -1 + (s+1)/2 = log2(n/s+1) + s/2 可见s即每块的长度越小越好*/
/*顺序查找时，ASLblk = ((b+1)+(s+1))/2 =1/2(n/s +s) +1 因为b = n/s向上取值，当s=根号n时最佳*/


