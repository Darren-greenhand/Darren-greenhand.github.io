#include <stdio.h>
#include <malloc.h>
//链串的创建都是用尾插法，因此都有一个工具节点r
//带头节点的单链表作为链串，结点大小是每个结点存储的字符个数,未占用的用特殊符号（#）填补
//链串中，节点大小越大，存储密度越大，基本操作有所不便，适合很少修改的情况，这里规定大小为1
typedef struct snode
{
    char data; //存放字符
    struct snode *next;
} LinkStrNode;

//要用尾插法保证顺序
void StrAssign(LinkStrNode *&s, char cstr[])
{
    int i;
    LinkStrNode *r, *p;
    s = (LinkStrNode *)malloc(sizeof(LinkStrNode));
    r = s;
    for (i = 0; cstr[i] != '\0'; i++)
    {
        p = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        p->data = cstr[i];
        r->next = p;
        r = p;
    }
}

void DestroyStr(LinkStrNode *&s)
{
    LinkStrNode *pre = s, *p = s->next;
    while (p != NULL)
    {
        free(p);
        pre = p;
        p = pre->next;
    }
    free(pre);
}

void StrCopy(LinkStrNode *&s, LinkStrNode *t)
{
    LinkStrNode *p = t->next, *q, *r;
    s = (LinkStrNode *)malloc(sizeof(LinkStrNode));
    r = s;
    while (p != NULL)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    r->next = NULL;
}

bool StrEqual(LinkStrNode *s, LinkStrNode *t)
{
    LinkStrNode *p = s->next, *q = t->next; //直接比较本身
    while (p != NULL && q != NULL && p->data == q->data)
    {
        p = p->next;
        q = q->next;
    }
    if (p->data == NULL && q->data == NULL)
        return true;
    else
        return false;
}

int StrLength(LinkStrNode *s)
{
    int i = 0;
    LinkStrNode *p = s->next;
    while (p->data != NULL)
    {
        p = p->next;
        i++;
    }
    return i;
}

//链接两个数组其实就是分别遍历一遍
LinkStrNode *Concat(LinkStrNode *s, LinkStrNode *t)
{
    LinkStrNode *str, *p = s->next, *q = t->next, *r;
    str = (LinkStrNode *)malloc(sizeof(LinkStrNode));
    while (p != NULL)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    p = t->next; //这样直接转过来，少一个工具节点，是我蠢了
    while (p != NULL)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    r->next = NULL;
    return str;
}

//当参数不正确的时候返回一个空串，这里需要调用之前已经封装好的函数
LinkStrNode *Substr(LinkStrNode *s, int i, int j)
{
    int k;
    LinkStrNode *str, *p = s->next, *q, *r; //经典四件套哈哈
    str = (LinkStrNode *)malloc(sizeof(LinkStrNode));
    str->next = NULL; //先把空串准备好在这里
    r = str;
    if (i <= 0 || i > StrLength(s) || j < 0 || i + j - 1 > StrLength(s))
        return str;
    for (k = 1; k < i; k++) //这里的k取得是1，因为要取到逻辑顺序第i位的前一位，而不是物理顺序
        p = p->next;
    for (k = 1; k <= j; k++)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    r->next = p;
    return str;
}

//怎么感觉这里所有的其实都差不多，都是链表啊啥的，没啥意思

LinkStrNode *InsStr(LinkStrNode *s, int i, LinkStrNode *t)
{
    int k;
    LinkStrNode *str, *p = s->next, *q, *r, *p1 = t->next;
    str = (LinkStrNode *)malloc(sizeof(LinkStrNode));
    str->next = NULL;
    r = str;
    if (i <= 0 || i > StrLength(s) + 1)
        return str;
    for (k = 1; k < i; k++)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    while (p1 != NULL)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p1->data;
        r->next = q;
        r = q;
        p1 = p1->next;
    }
    while (p != NULL)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    r->next = NULL;
    return str;
}

//这个基本上都是完全一样的，直接copy一部分，瞬间刷完，我吐了，这些那么相似的还搞
LinkStrNode *DelStr(LinkStrNode *s, int i, int j)
{
    int k;
    LinkStrNode *str, *p = s->next, *q, *r;
    str = (LinkStrNode *)malloc(sizeof(LinkStrNode));
    str->next = NULL;
    if (i <= 0 || i > StrLength(s) || j < 0 || i + j - 1 > StrLength(s))
        return str;
    for (k = 1; k < i; k++)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    for (k = 0; k < j; k++) //这里的k应该是0，因为这个就不是逻辑序号，而是物理上的序号了
        p = p->next;
    while (p != NULL)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    r->next = NULL;
    return str;
}

LinkStrNode *RepStr(LinkStrNode *s, int i, int j, LinkStrNode *t)
{
    int k;
    LinkStrNode *str, *p = s->next, *q, *r, *p1 = t->next;
    str = (LinkStrNode *)malloc(sizeof(LinkStrNode));
    str->next = NULL;
    if (i <= 0 || i > StrLength(s) || j < 0 || i + j - 1 > StrLength(s))
        return str;
    for (k = 0; k < i - 1; k++) //这样的其实也是逻辑，所以i-1，使用哪种看自己喜欢吧
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    while (p1 != NULL)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    for (k = 0; k < j; k++)
        p = p->next;
    while (p != NULL)
    {
        q = (LinkStrNode *)malloc(sizeof(LinkStrNode));
        q->data = p->data;
        r->next = q;
        r = q;
        p = p->next;
    }
    r->next = NULL;
    return str;
}
//好垃圾啊，，真的全都一样的，我感觉我都能背下来了

void DispStr(LinkStrNode *s)
{
    LinkStrNode *p = s->next;
    while (p != NULL)
    {
        printf("%c", p->data);
        p = p->next;
    }
    printf("\n");
}


