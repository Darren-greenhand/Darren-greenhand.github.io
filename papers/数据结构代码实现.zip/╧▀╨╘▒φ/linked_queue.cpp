#include <stdio.h>
#include <malloc.h>

typedef int ElemType;
typedef struct qnode
{
    ElemType data;
    struct qnode *next;
} DataNode;

//需要一个链队节点
typedef struct
{
    DataNode *front;
    DataNode *rear;
} LinkQuNode;

void InitQueue(LinkQuNode *&q)
{
    q = (LinkQuNode *)malloc(sizeof(LinkQuNode));
    q->front = q->rear = NULL;
}

void DestroyQueue(LinkQuNode *&q)
{
    DataNode *pre = q->front, *p;
    if (pre != NULL)
    {
        p = pre->next;
        while (p != NULL)
        {
            free(pre);
            pre = p;
            p = pre->next;
        }
        free(pre); //这个怎么总是忘掉啊！
    }
    free(q);
}

bool QueueEmpty(LinkQuNode *q)
{
    return (q->rear == NULL);
}

void enqueue(LinkQuNode *&q, ElemType e) //因为无限长度，所以类型是bool
{
    DataNode *p;
    p = (DataNode *)malloc(sizeof(DataNode));
    p->data = e;
    p->next = NULL;
    if (q->rear == NULL)
        q->front = q->rear = p; //还要判断是不是空列表！！！
    else
    {
        q->rear->next = p;
        q->rear = p;
    }
}

bool dequeue(LinkQuNode *&q, ElemType &e)
{
    DataNode *t;
    if (q->rear == NULL)
        return false;
    t = q->front;            //两种情况都可以先将t指过来
    if (q->front == q->rear) //只有一个节点
        q->front = q->rear = NULL;
    else
        q->front = t->next;
    free(t);
    return true;
}
