#include <stdio.h>
#include <malloc.h>
/*先看看顺序存储结构
对于完全二叉树和满二叉树，可以实现随机存储，完全二叉树最后几个空的用 # 表示
对于一般的二叉树，可以增添一些不存在的空结点，使之成为一棵完全二叉树的形式。
图可以看看P204  */
#define MaxSize 100 //假设最多只有100个非零项
typedef int ElemType;
typedef ElemType SqBinTree[MaxSize];
//但是如果空的太多，会造成空间的大量浪费，但是查找子节点和父节点都很方便。
//当然还有一般顺序存储结构的缺点，就是插入，删除很不方便

//链式存储，称为二叉链，用根节点指针b唯一标识整个存储结构，称为二叉树b
typedef struct node
{
    ElemType data;
    struct node *lchild;
    struct node *rchild;
    //struct node *parent;
} BTNode;
//这样节省空间，但不方便访问父节点，可以增加一个指向父节点的指针域parent来解决。
//后续一般假设一棵二叉树中所有结点值均不同，为单个字符
//创建，销毁，按值查找（父），找孩子，求高度，输出   创建和输出都用括号表示法

//首先得理解二叉树的括号表示，模拟一个栈来实现,因为栈的实现很简单，并没有封装
//这个用栈保存双亲结点的思想太妙了！栈顶存放的是当前处理节点的父节点
void CreateBTree(BTNode *&b, char *str)
{
    BTNode *St[MaxSize], *p; //St为顺序栈
    int top = -1, k, j = 0;  //j为str索引,k用来判断孩子类型
    char ch;
    b = NULL;
    ch = str[j];
    while (ch != '\0')
    {
        switch (ch)
        {
        case '(':
            top++;
            St[top] = p;
            k = 1;
            break;
        case ')':
            top--;
            break;
        case ',':
            k = 2;
            break;
        default:
            p = (BTNode *)malloc(sizeof(BTNode));
            p->data = ch;
            p->lchild = p->rchild = NULL;
            if (b == NULL)
                b = p; //这是只存在一次的还未建立根节点的情况
            else
            {
                switch (k)
                {
                case 1:
                    St[top]->lchild = p;
                    break;
                case 2:
                    St[top]->rchild = p;
                    break;
                }
            }
        }
        j++;
        ch = str[j];
    }
}

void DestroyBTree(BTNode *&b)
{
    if (b != NULL)
    {
        DestroyBTree(b->lchild);
        DestroyBTree(b->rchild);
        free(b);
    }
}

//查找x的结点
BTNode *FindeNode(BTNode *b, ElemType x)
{
    BTNode *p;
    if (b == NULL)
        return NULL;
    else if (b->data == x)
        return b;
    else
    {
        p = FindeNode(b->lchild, x);
        if (p != NULL)
            return p;
        else
            return FindeNode(b->rchild, x);
        //这也把没找到的情况包含在内了，要学会简化代码
    }
}

BTNode *LchildNode(BTNode *p)
{
    return p->lchild;
}

BTNode *RchildNode(BTNode *p)
{
    return p->rchild;
}

//求高度
int BTHeight(BTNode *b)
{
    int lchild, rchild;
    if (b == NULL)
        return 0;
    else
    {
        lchild = BTHeight(b->lchild);
        rchild = BTHeight(b->rchild);
    }
    return (lchild > rchild ? lchild : rchild) + 1;
}

//终究还是比广义表简单不少啊,当是NULL的时候不操作，非常流弊
void DispBTree(BTNode *b)
{
    if (b != NULL)
    {
        printf("%c", b->data);
        if (b->lchild != NULL || b->rchild != NULL)
        {
            printf("(");
            DispBTree(b->lchild);
            printf(",");
            DispBTree(b->rchild);
            printf(")");
        }
    }
}

int main()
{
    //突然想玩一下下
    char str[MaxSize] = "A(B(D(,G))C(E,F))";
    BTNode *BT;
    CreateBTree(BT, str);
    DispBTree(BT);
    printf("\nI prefer Python, C is to complex and confused");
}

/*遍历，四种顺序，层次遍历是非递归的
一颗二叉树可以分为根节点和子树两类，根节点直接处理，子树递归处理
如果必须先处理子树，那就用后序，如果必须先处理根节点，那就用先序，否则随便
如果要区分左，右树，那就要考虑中序，但是比较少*/
void Preorder(BTNode *b)
{
    if (b != NULL)
    {
        printf("%c", b->data);
        Preorder(b->lchild);
        Preorder(b->rchild);
    }
}

void Inorder(BTNode *b)
{
    if (b != NULL)
    {
        Inorder(b->lchild);
        printf("%c", b->data);
        Inorder(b->rchild);
    }
}

void PostOrder(BTNode *b)
{
    if (b != NULL)
    {
        PostOrder(b->lchild);
        PostOrder(b->rchild);
        printf("%c", b->data);
    }
}

//求给定二叉树的所有结点个数
int Nodes(BTNode *b)
{
    if (b == NULL)
        return 0;
    else
        return Nodes(b->lchild) + Nodes(b->rchild) + 1;
    //这个是先左后右后根，是后续遍历
}
//输出所有的叶子节点
/*递归模型很重要！
f(b) === 不做任何事情    b=NULL
f(b) === 输出b的data域   b为叶子结点
f(b) === f(b->lchild);f(b->rchild) 其他情况*/
void DispLeaf(BTNode *b)
{
    if (b != NULL)
    {
        if (b->lchild == NULL && b->rchild == NULL)
            printf("%c", b->data);
        DispLeaf(b->lchild);
        DispLeaf(b->rchild);
    }
}

//求深度，h置处置1，这个和之前那个稍微有点不同，具体分析
int Level(BTNode *b, ElemType x, int h = 1)
{
    int l;
    if (b == NULL)
        return 0;
    else if (b->data == x)
        return h;
    else
    {
        l = Level(b->lchild, x, h + 1);
        if (l)
            return l;
        else
            return (Level(b->rchild, x, h + 1)); //又见到了这种操作
    }
}

//求b树第k层的结点数,h是用来传递参数，初始为1
//这是另一种递归思路，并没有回带的过程，利用了void和引用
//如果在c语言中，可以用全局变量来代替所谓的引用。
void Lnodenum(BTNode *b, int k, int h = 1, int &n)
{
    if (b == NULL)
        return;
    else
    {
        if (k == h)
        {
            n++;
        }
        else if (h < k)
        {
            Lnodenum(b->lchild, h + 1, k, n);
            Lnodenum(b->rchild, h + 1, k, n);
        }
    }
}

//输出x的结点的所有祖先,多判断一级的思维
bool ancestor(BTNode *b, ElemType x)
{
    if (b == NULL)
        return false;
    else if (b->lchild != NULL && b->lchild->data == x || b->rchild != NULL && b->rchild->data == x)
    {
        putchar(b->data);
        return true;
    }
    else if (ancestor(b->lchild, x) || ancestor(b->rchild, x))
    {

        putchar(b->data);
        return true;
    }
    else
        return false;
}

//非递归算法区域P218
//层次遍历算法
typedef struct
{
    BTNode *data[MaxSize];
    int front, rear;
} SqQueue;

/*
void LevelOrder(BTNode *b)
{
    BTNode *p;
    SqQueue *qu;
    enqueue(qu, b);
    while (!QueueEmpty(qu))
    {
        deQueue(qu, p);
        putchar(p->data);
        if (p->lchild != NULL)
            enqueue(qu, p->lchild);
        if (p->rchild != NULL)
            enqueue(qu, p->rchild);
    }
}
*/

//二叉树的构造
//pre存放先序序列，in存放中序序列，n为二叉树的节点个数
//其实函数的参数选择同时得考虑递归时不同层级间需要的参数
BTNode *CreateBT1(char *pre, char *in, int n)
{
    BTNode *b;
    char *p;
    int k;
    if (n <= 0)
        return NULL;
    b = (BTNode *)malloc(sizeof(BTNode));
    b->data = *pre; //根节点
    for (p = in; p < in + n; p++)
        if (*p == *pre)
            break;
    k = p - in; //确定根节点在in中的位置
    b->lchild = CreateBT1(pre + 1, in, k);
    b->rchild = CreateBT1(pre + k + 1, p + 1, n - k - 1);
    //这里不能光考虑第一次的，要用通用的写法
    return b;
}

//和上面基本一致
BTNode *CreateBT2(char *post, char *in, int n)
{
    BTNode *b;
    char r, *p; //因为根节点在后头，所以得用一个变量单独保存
    int k;
    if (n <= 0)
        return NULL;
    b = (BTNode *)malloc(sizeof(BTNode));
    r = *(post + n - 1);
    b->data = r;
    for (p = post; p < post + n; p++)
    {
        if (*p == r)
            break;
    }
    k = p - post;
    b->lchild = CreateBT2(post, in, k);
    b->rchild = CreateBT2(post + k, p + 1, n - k + 1);
    return b;
}

//哈夫曼树采用数组存放，总的结点数可以算出来 P239
//前n个存放原结点（叶子结点），剩下的存放分支节点。
//思路是先将全部节点的parent、lchild、rchild赋值为-1,然后不断找最小的放在后面，同时补全信息
typedef struct
{
    char data;
    double weight;
    int parent;
    int lchild;
    int rchild;
} HTNode;

void CreateHT(HTNode ht[], int n0)
{
    int i, k, lnode, rnode;
    double min1, min2;
    for (i = 0; i < 2 * n0 + 1; i++)
        ht[i].parent = ht[i].lchild = ht[i].rchild = -1;
    for (i = n0; i < 2 * n0 - 1; i++)
    {
        min1 = min2 = 32767;
        lnode = rnode = -1;
        for (k = 0; k < i - 1; k++)
            //通过确定两个最小值的相对次序来巧妙地处理该问题
            if (ht[k].parent == -1)
            { //在尚未构造二叉树的结点中查找
                if (ht[k].weight < min1)
                {
                    min2 = min1;
                    rnode = lnode;
                    min1 = ht[k].weight;
                    lnode = k;
                }
                else if (ht[k].weight < min2)
                {
                    min2 = ht[k].weight;
                    rnode = k;
                }
            }
        ht[i].weight = ht[lnode].weight + ht[rnode].weight;
        ht[i].lchild = lnode;
        ht[i].rchild = rnode;
        ht[lnode].parent = i;
        ht[rnode].parent = i;
    }
}

//哈夫曼编码,规定左分支为0，右分支为1
#define N 100
typedef struct
{
    char cd[N]; //存放当前节点的哈夫曼编码
    int start;  //表明cd[start..n0]部分是哈夫曼编码
} HCode;

//这是个从下向上的过程，但是最终是顺序的
void CreateHCode(HTNode ht[], HCode hcd[], int n0)
{
    int i, f, c;
    HCode hc;
    for (i = 0; i < n0; i++)
    {
        hc.start = n0;
        c = i;
        f = ht[i].parent; //初始化
        while (f != -1)
        { //循环到根节点
            if (ht[f].lchild == c)
                hc.cd[hc.start--] = '0';
            else
                hc.cd[hc.start--] = '1';
            c = f;
            f = ht[f].parent;
        }
        hc.start++; //因为多减了一次，加回来
        hcd[i] = hc;
    }
}

