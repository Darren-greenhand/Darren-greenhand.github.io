#include <stdlib.h>
#include <stdio.h>

//基本数据类型
typedef int KeyType;
typedef struct
{
    int one;
    char two;
} InfoType;
typedef struct
{
    KeyType key;
    InfoType data;
} RecType;

//插入排序
//直接插入排序
void InsertSort(RecType R[], int n)
{
    int i, j;
    RecType tmp;
    for (i = 1; i < n; i++)
    {
        if (R[i].key < R[i - 1].key) //如果直接就大于有序区最大的，
        {
            tmp = R[i];
            j = n - 1;
            do
            {
                R[j + 1] = R[j];
                j--;
            } while (j >= 0 && R[j].key > tmp.key);
            R[j + 1] = tmp;
        }
    }
}

//折半插入排序
//在有序区查找位置时用折半查找就好了
void BinInsertSort(RecType R[], int n)
{
    int i, j, low, high, mid;
    RecType tmp;
    for (i = 1; i < n; i++)
    {
        if (R[i].key < R[i - 1].key)
        {
            tmp = R[i];
            low = 0;
            high = i - 1;
            while (low <= high)
            {
                mid = (low + high) / 2;
                if (tmp.key < R[mid].key)
                    high = mid - 1;
                else
                    low = mid + 1;
            }
            for (j = i - 1; j >= high + 1; j--)
                R[j + 1] = R[j];
            R[high + 1] = tmp;
        }
    }
}

//希尔排序
//这和上一章查找好像啊，分组插入,原理我感觉是避免高次运算的爆炸增长
//这里取di+1 = di/2向下取整,d1 = n/2
void ShellSort(RecType R[], int n)
{
    int i, j, d = n / 2;
    RecType tmp;
    while (d > 0)
    {
        for (i = d; i < n; i++) //这个上下界真是绝了，一步到位全部都排好，我还想了一会
        {
            tmp = R[i];
            j = i - d;
            while (j >= 0 && tmp.key < R[j].key)
            {
                R[j + d] = R[j];
                j = j - d;
            }
            R[j + d] = tmp;
        }
        d = d / 2;
    }
}

//交换排序
//冒泡排序,从后开始
void BubbleSort(RecType R[], int n)
{
    int i, j;
    RecType tmp;
    for (i = 0; i < n - 1; i++)
        for (j = n - 1; j > i; j--)
            if (R[j].key < R[j - 1].key)
            {
                tmp = R[j];
                R[j] = R[j - 1];
                R[j - 1] = tmp;
            }
}
//实际上，一旦某一趟不出现任何元素交换，就说明排好序了，可以用一个flag来达到这点

//快速排序 当年初学感觉非常巧妙的算法哈哈
//选一个枢纽（一般第一个），然后将所有的放在其前后，递归进行处理

int partition(RecType R[], int s, int t)
{ //从头尾向中扫描
    int i = s, j = t;
    RecType tmp = R[i];
    while (i < j)
    {
        while (j > i && R[j].key >= tmp.key)
            j--;
        R[i] = R[j];
        while (i > j && R[i].key <= tmp.key)
            i++;
        R[j] = R[i];
    }
    R[i] = tmp;
    return i;
}

void QuickSort(RecType R[], int s, int t) //对R[s...t]元素进行快速排序
{
    int i;
    if (s < t)
    {
        i = partition(R, s, t);
        QuickSort(R, s, i - 1);
        QuickSort(R, s + 1, t);
    }
}

//选择排序
//基本思路是每一趟都挑出最大、最小的，适合从大量元素中选择一部分排序元素

//简单选择选择
//分成有序区和无序区，从无序区选出最的后与无序区第一个元素交换，之所以叫简单排序是因为找最小值的方法是简单的两两比较
void SelectSort(RecType R[], int n)
{
    int i, j, k;
    RecType tmp;
    for (i = 0; i < n - 1; i++)
    {
        k = i;
        for (j = i + 1; j < n; j++)
            if (R[j].key < R[k].key)
                k = j; //k记录最值的位置
        if (k != i)
        {
            tmp = R[k];
            R[k] = R[i];
        }
    }
}

//堆排序
/*看成是一颗完全二叉树的顺序存储结构，大根堆，小根堆，挑选最大元素是采用筛选方法实现的
筛选：假定某节点左右子树是大根堆，选择子节点和本身最大的上来，由于可能会破坏子树，因此递归判断*/
void sift(RecType R[], int low, int high)
{
    int i = low, j = 2 * i; //low是根节点,j指向当前结点的孩子
    RecType tmp = R[i];
    while (j <= high)
    {
        if (j < high && R[j].key < R[j + 1].key)
            j++; //看看两个孩子谁大
        if (tmp.key < R[j].key)
        {
            R[i] = R[j];
            i = j;
            j = 2 * i; //这个索引的变换有点巧妙
        }
        else
            break; //筛选结束
    }
    R[i] = tmp;
}

//构建初始堆，从最后一个分支点n/2向下取整开始，反复筛选
//for(i = n/2;i>=1;i--) sift(R,i,n)

void HeapSort(RecType R[], int n)
{
    int i;
    RecType tmp;
    for (i = n / 2; i >= 1; i--)
        sift(R, i, n); //建立初始堆
    //每次抽掉“根”，就是堆上最大那个
    for (i = n; i >= 2; i--)
    {
        tmp = R[1];
        R[1] = R[i];
        R[i] = tmp;
        sift(R, 1, i - 1);
    }
}

//基数排序
#define MAXD 10000 //最大关键字位数
#define MAXR 10    //每一位的取值上限（开区间）
typedef struct node
{
    char data[MAXD];   //存放关键字的各位
    struct node *next; //指向下一个结点
} NodeType;

//输入数据为p为首节点的单链表
void RadixSort(NodeType *&p, int r, int d)
{
    NodeType *head[MAXR], *tail[MAXR], *t;
    int i, j, k;
    for (i = 0; i < d - 1; i++)
    {
        for (j = 0; j < r; j++)
            head[j] = head[i] = NULL; //初始化指针
        while (p != NULL)             //将原链表所有节点分配到链队
        {
            k = p->data[i] - '0'; //找到第k个链队
            if (head[j] == NULL)
            {
                head[k] = p;
                tail[k] = p;
            }
            else
            {
                tail[j]->next = p;
                tail[k] = p;
            }
            p = p->next;
        }
        p = NULL; //重新用p来收集所有节点
        for (j = 0; j < r; j++)
        {
            if (head[j] != NULL) //找到第一个非空链队,通过首位指针处理，中间已经连好了
            {
                if (p == NULL)
                {
                    p = head[j];
                    t = tail[j];
                }
                else
                {
                    t->next = head[j];
                    t = tail[k]; //如果不是第一个,就连上来
                }
            }
        }
        t->next = NULL; //别忘了！！！！！卧槽结束了！
    }
}
