#define MAXV 100  //最大结点数
#define INF 32767 //所谓的正无穷，也就是没有路
#include <stdio.h>
#include <stdlib.h>
typedef int InfoType;
typedef struct
{
    int no;        //顶点编号
    InfoType info; //其他信息
} VertexType;

typedef struct
{
    int edges[MAXV][MAXV]; //邻接矩阵数组
    int n, e;              //顶点数、边数
    VertexType vexs[MAXV]; //存放结点信息
} MatGraph;

/*适合储存边比较多的稠密图
邻接矩阵表示是唯一的，注意无向图、有向图每一行/列的意义
非常适合提取两个顶点之间的边，适用于该目的的算法*/

//邻接表结构是后续众多算法的基础，一定要弄清楚P259
//每个顶点一个链表，链接关联的边。其中的每个边结点表示一条！边！的信息，not 点
//头节点存储的则是顶点的信息，并指向首节点。
typedef struct ANode
{
    int adjvex;            //该边的临界点编号,指的是出边临界点
    struct ANode *nextarc; //指向下个边的指针
    int weight;            //该边的相关信息
} ArcNode;

typedef struct Vnode
{
    InfoType info;
    ArcNode *firstarc;
} VNode;

typedef struct
{
    VNode adjlist[MAXV]; //头节点数组
    int n, e;
} AdjGraph;
//还有所谓的逆邻接表
/*邻接表的表示不唯一，取决于算法和输入次序，适合边数目稀疏的图
对于无向图，第i个单链表的边数目是顶点i的度，有向图则为出度，入度得统计所有的adjvex域为i的数目
适合提取某个顶点的所有临界点*/

//依次扫描，头插法插入。
void CreateAdj(AdjGraph *&G, int A[MAXV][MAXV], int n, int e)
{
    int i, j;
    ArcNode *p;
    for (i = 0; i < n; i++)
        G->adjlist[i].firstarc = NULL; //初始化
    for (i = 0; i < n; i++)
        for (j = n - 1; j >= 0; j--)
            if (A[i][j] != 0 && A[i][j] != INF)
            {
                p = (ArcNode *)malloc(sizeof(ArcNode));
                p->adjvex = j;
                p->weight = A[i][j];
                p->nextarc = G->adjlist[i].firstarc;
                G->adjlist[i].firstarc = p;
            }
    G->n = n;
    G->e = e;
}

//输出规则为先输出头结点的定点信息，再依次输出所有结点的顶点编号
void DispAdj(AdjGraph *G)
{
    int i;
    ArcNode *p;
    for (i = 0; i < G->n; i++)
    {
        p = G->adjlist[i].firstarc;
        printf("%3d:", i);
        while (p != NULL)
        {
            printf("%3d[%d]", p->adjvex, p->weight);
            p = p->nextarc;
        }
        printf("\n");
    }
}

void DestroyAdj(AdjGraph *&G)
{
    int i;
    ArcNode *pre, *p;
    for (i = 0; i < G->n; i++)
    {
        pre = G->adjlist[i].firstarc;
        if (pre != NULL)
        {
            p = pre->nextarc;
            while (p != NULL)
            {
                free(p);
                pre = p;
                p = pre->nextarc;
            }
            free(pre);
        }
    }
    free(G); //别忘了把头节点数组也释放掉
}

//将邻接表转换为邻接矩阵
void ListToMat(AdjGraph *&G, MatGraph &g)
{
    int i;
    ArcNode *p;
    for (i = 0; i < G->n; i++)
    {
        p = G->adjlist[i].firstarc;
        while (p != NULL)
        {
            g.edges[i][p->adjvex] = p->weight;
            p = p->nextarc;
        }
    }
    g.n = G->n;
    g.e = G->e;
}

/*十字链表
是给有向图用的，是邻接表和逆邻接表的结合，现在看其实非常简单。。不知道当时为啥讲那么久。*/

//图的遍历，要求每个顶点仅被访问一次。
//因为图不像树，存在回路，得设置一个访问标记数组visited,当访问过时置1，否则为0

//深度优先Depyh First Search DFS
int visited[MAXV] = {0}; //全局置0,从v开始遍历
void DFS(AdjGraph *G, int v)
{
    ArcNode *p;
    visited[v] = 1;
    printf("%2d", v);
    p = G->adjlist[v].firstarc;
    while (p != NULL)
    {
        if (visited[p->adjvex] == 0)
            DFS(G, p->adjvex);
        p = p->nextarc;
    }
}

//广度优先算法Breadth First Search BFS,显然这种结构要用到队列
#include "linked_queue.cpp"
void BFS(AdjGraph *G, int v)
{
    int w, i;
    ArcNode *p;
    LinkQuNode *qu;
    InitQueue(qu);
    int visited[MAXV];
    for (i = 0; i < G->n; i++)
        visited[i] = 0;
    printf("%2d", v);
    visited[v] = 1;
    enqueue(qu, v);
    while (!QueueEmpty(qu))
    {
        dequeue(qu, w);
        p = G->adjlist[w].firstarc;
        //这个while一套用的也挺多的
        while (p != NULL)
        {
            if (visited[p->adjvex] == 0)
            {
                printf("%2d", p->adjvex);
                visited[p->adjvex] = 1;
                enqueue(qu, p->adjvex);
            }
            p = p->nextarc;
        }
    }
    printf("\n");
}

//遍历非连通图
void DFS1(AdjGraph *G)
{
    int i;
    for (i = 0; i < G->n; i++)
        if (visited[i] == 0)
            DFS(G, i);
}

void BFS1(AdjGraph *G)
{
    int i;
    for (i = 0; i < G->n; i++)
        if (visited[i] == 0)
            BFS(G, i);
}

bool Connect(AdjGraph *G)
{
    int i;
    bool flag = true;
    for (i = 0; i < G->n; i++)
        visited[i] = 0;
    DFS(G, 0);
    for (i = 0; i < G->n; i++)
        if (visited[i] == 0)
        {
            flag = false;
            break;
        }
    return flag;
}

//图遍历算法的应用

//深度搜索判断是否存在路径。
void ExitPath(AdjGraph *G, int u, int v, bool &has)
{
    int w;
    ArcNode *p;
    visited[u] = 1;
    if (u == v)
    {
        has = true;
        return;
    }
    p = G->adjlist[u].firstarc;
    while (p != NULL)
    {
        w = p->adjvex;
        if (visited[w] == 0)
            ExitPath(G, w, v, has);
        p = p->nextarc;
    }
}

//输出从u到v的一条路径，假设已知u到v间有路径。
//只要正常遍历就好，绝对会输出一条路径，不过非常随机就是了。
void FindaPath(AdjGraph *G, int u, int v, int path[], int d)
{
    //d表示path中的路径长度，初始为-1
    int w, i;
    ArcNode *p;
    visited[u] = 1;
    d++;
    path[d] = u;
    if (u == v)
    {
        for (i = 0; i <= d; i++)
        {
            printf("%d", path[i]);
            printf("\n");
            return;
        }
    }
    p = G->adjlist[u].firstarc;
    while (p != NULL)
    {
        w = p->adjvex;
        if (visited[w] == 0)
            FindaPath(G, w, v, path, d);
        p = p->nextarc;
    }
}

//这个递归还是让人想了一会
void FindALLPath(AdjGraph *G, int u, int v, int path[], int d)
{

    //d表示path中的路径长度，初始为-1
    int w, i;
    ArcNode *p;
    visited[u] = 1;
    d++;
    path[d] = u;
    if (u == v)
    {
        for (i = 0; i <= d; i++)
        {
            printf("%d", path[i]);
            printf("\n");
            return;
        }
    }
    p = G->adjlist[u].firstarc;
    while (p != NULL)
    {
        w = p->adjvex;
        if (visited[w] == 0)
        {
            FindALLPath(G, w, v, path, d);
            p = p->nextarc; //递归体的核心就在这里
        }
    }
    visited[u] = 0; //恢复环境，可以重复利用。
}

// Prim算法
//建议先阅读一下P284,搞清楚lowcost(到U中的最小边)和closet（最小边对应的顶点）,这种实时更新最值的思想很有用，简化了算法
void Prim(MatGraph g, int v)
{
    int lowcost[MAXV];
    int MIN;
    int closet[MAXV], i, j, k;
    for (i = 0; i < g.n; i++)
    {
        lowcost[i] = g.edges[v][i];
        closet[i] = v;
        //初始化
    }
    for (i = 1; i < g.n; i++) //找出n - 1个顶点
    {
        MIN = INF;
        for (j = 0; j < g.n; j++)
            if (lowcost[j] != 0 && lowcost[j] < MIN)
            {
                MIN = lowcost[j];
                k = j; //k记录最小边的顶点编号
            }
        printf("边(%d,%d)权为%d\n", closet[k], k, MIN); //输出最小生成树的一条边
        lowcost[k] = 0;                                 //标记k已经加入U中
        for (j = 0; j < g.n; j++)
            if (lowcost[j] != 0 && g.edges[k][j] < lowcost[j])
            {
                lowcost[j] = g.edges[k][j];
                closet[j] = k;
            }
    }
}

//克鲁斯卡尔
typedef struct
{
    int u;
    int v;
    int w;
    //起始顶点，终止顶点和权值
} Edge;
#define Maxsize 20000 //最大边数
void Kruskal(MatGraph g)
{
    int i, j, u1, v1, sn1, sn2, k;
    int vset[MAXV];
    Edge E[Maxsize]; //存放所有的边
    k = 0;           //e数组的下标
    //第一步，由g产生E
    for (i = 0; i < g.n; i++)
        for (j = 0; j < g.n; j++)

            if (g.edges[i][j] != 0 && g.edges[i][j] != INF)
            {
                E[k].u = i;
                E[k].v = k;
                E[k].w = g.edges[i][j];
                k++;
            }
    //InsertSort(E,g.e)//对所有的边按照权值排序
    for (i = 0; i < g.n; i++)
        vset[i] = i; //初始化辅助数组
    k = 1;           //表示当前构造生成树的第几条边，初始为1
    j = 0;           //E中边的下标，初始为0

    //主体
    while (k < g.n) //生成树有n-1条边
    {
        u1 = E[j].u;
        v1 = E[j].v;
        sn1 = vset[u1];
        sn2 = vset[v1];
        if (sn1 != sn2)
        {
            printf("(%d,%d):%d\n", u1, v1, E[j].w); //输出一条边
            k++;
            for (i = 0; i < g.n; i++)
                if (vset[i] == sn2)
                    vset[i] = sn1;
        }
        j++;
    }
}


//最短路径 1.求某个顶点到其他顶点的最短路径。 2.求每一对顶点间的最短路径
//狄克斯特拉算法（权值一定大于0）
