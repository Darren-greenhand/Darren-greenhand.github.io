#include <stdio.h>
#include <malloc.h>
typedef int ElemType;
typedef struct lnode
{
    int tag; //标识符 0为原子节点，1为表节点
    union
    {
        ElemType data;         //存放数据值
        struct lnode *sublist; //指向子表的指针
    } val;
    struct lnode *link; //同一层的下一个元素
} GLNode;

//tag = 1的节点可以看成是一个单链表的头节点，指向子表的首节点,通过递归性，有两种解法
//解法1，把整个看成一个带头节点的单链表，种类分原子和子表，子表类似整个表，而原子则仅仅是原子处理罢了。
void fun1(GLNode *g)
{
    GLNode *gl = g->val.sublist;
    while (gl != NULL)
    {
        if (gl->tag == 1)
            fun1(gl);
        else
        {
            printf("原子处理语句");
        }
        gl = gl->link; //处理后继元素
    }
}

//解法2，对于元素节点，其兄弟域的节点和整个广义表是相似的，对于表节点，其元素域和兄弟域的处理均与整个广义表相似
void fun2(GLNode *g)
{
    if (g != NULL)
    {
        if (g->tag == 1)          //为子表
            fun2(g->val.sublist); //先递归处理表节点的元素域
        else
        {
            printf("原子处理语句");
        }
        fun2(g->link); //处理两种节点的兄弟（不用分类，因为无论什么节点，兄弟都相似于整个表）
    }
}
//实际问题中根据求解问题的特点自行选择其中来设计递归求解

int GLLength(GLNode *g)
{
    int n = 0;
    GLNode *gl = g->val.sublist;
    while (g != NULL)
    {
        n++;
        gl = gl->link; //只用算最表层的哈哈
    }
    return n;
}

int GLDepth(GLNode *g)
{
    GLNode *gl;
    int maxd = 0, dep; //maxd是同一层子表中深度的最大值
    if (g->tag == 0)
        return 0;
    gl = g->val.sublist;
    if (gl == NULL)
        return 1;

    //这下面这个操作还是挺妙的
    while (gl != NULL)
    {
        if (gl->tag == 1)
        {
            dep = GLDepth(gl->val.sublist); //dep代表该节点的深度！自顶向下
            if (dep > maxd)
                maxd = dep;
        }
        gl = gl->link;
    }
    return (maxd + 1); //返回这一层的最大值到上一层的节点
}

//要输出成括号的形式还是有点麻烦的，元素直接输出值，子表则输出 ‘（’，空表输出‘#’，非空子表递归，再输出‘）’
void DispGL(GLNode *g)
{
    if (g != NULL)
    {
        if (g->tag == 0)
            printf("%c", g->val.data);
        else
        {
            printf("(");
            if (g->val.sublist == NULL)
                printf("#");
            else
                DispGL(g->val.sublist);
            printf(")"); //这个括号挺妙的，不要漏了
        }
        if (g->link != NULL)
        {
            printf(",");
            DispGL(g->link); //兄弟应该在子表后面输出
        }
    }
}

//与输出对应的，建立广义表的链式存储结构,记得空表是 “#”，遇到则将g->val.sublist置空
//扫描到 （ 则用g递归开启一个子表节点，遇到 ）说明已经处理完，g置空
//时空复杂的均为O（n）
//切记把链式结构和符号表示分开想，不要混在一起！
GLNode *CreateGL(char *&s)
{
    GLNode *g;
    char ch = *s++; //取一个字符,直接操作指针的话，便于后续调用
    if (ch != '\0')
    {
        g = (GLNode *)malloc(sizeof(GLNode));
        if (ch == '(')
        {
            g->tag = 1;
            g->val.sublist = CreateGL(s);
        }
        else if (ch == ')')
            g = NULL;
        else if (ch == '#')
            g = NULL;
        else
        {
            g->tag = 0;
            g->val.data = ch;
        }
    }
    else
        g = NULL; //若s扫描完，把g置空
    ch = *s++;
    if (g != NULL)
    {
        if (ch == ',')
            g->link = CreateGL(s);
        else
            g->link = NULL;
    }
    return g;
}

//采用解法1,递归销毁，注意要灵活一点，顺序什么的不影响那么怎样方便怎样来
void DestroyGL(GLNode *&g)
{
    GLNode *g1, *g2;
    g1 = g->val.sublist;
    while (g1 != NULL)
    {
        if (g1->tag == 0)
        {
            g2 = g1->link; //保存兄弟节点
            free(g1);
            g1 = g2;
        }
        else
        {
            g2 = g1->link;
            DestroyGL(g1->val.sublist);
            g1 = g2;
        }
    }
    free(g);
}

//计数方法，采用两种解法实现
int Count1(GLNode *g)
{
    int n = 0;
    GLNode *gl = g->val.sublist;
    while (gl != NULL)
    {
        if (gl->tag == 0)
            n++;
        else
            n += Count1(gl->val.sublist);
        gl = gl->link;
    }
    return n;
}

int Count2(GLNode *g)
{
    int n = 0;
    GLNode *gl = g->val.sublist;
    while (gl != NULL)
    {
        if (gl->tag == 1)
            n += Count2(gl->val.sublist);
        else
            n++;
        n += Count2(g->link);
    }
    return n;
}

